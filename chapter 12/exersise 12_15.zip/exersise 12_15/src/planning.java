import java.util.Scanner;

public class planning {

	public static void main(String[] args) throws java.io.IOException {
		java.io.File file = new java.io.File("Exersise12_15.txt");
		
		java.io.PrintWriter output = new java.io.PrintWriter(file);
		for(int i = 0; i <= 99; i++) {
			output.print((int) (Math.random() * 100) + " ");
		}
		output.close();
		Scanner input = new Scanner(file);
		int[] list = new int[101];
		for(int i = 0; i < list.length - 1; i++) {
			list[i] = input.nextInt();
		}
		input.close();
		int x = list.length - 1;
		int max = 0;
		int indexOfMax = 0;
		int num = 0;
		for(int i = 0; i < x; x--) {
			max = 0;
			for(int i1 = 0; i1 < x; i1++) {
				if(list[i1] > max) {
					max = list[i1];
					indexOfMax = i1;
				}
			}
			if(list[indexOfMax] >= list[x]) {
				num = list[indexOfMax];
				list[indexOfMax] = list[x];
				list[x] = num;
			}
		}
		for(int i = 0; i < list.length - 1; i++) {
			System.out.print(list[i] + " ");
		}
		
	}

}
