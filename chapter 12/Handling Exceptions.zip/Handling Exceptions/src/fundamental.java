import java.util.Scanner;
public class fundamental {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] list = new int[100];
		int x;
		for(int i = 0; i < list.length - 1; i++) {
			list[i] = (int) ((Math.random() * 100));
		}
		System.out.print("Enter a integer 0-99: ");
		x = input.nextInt();
		if(x < 100 && x > -1) {
			System.out.print(list[x]);
		}else {
			System.out.print("Out of Bounds");
		}

	}

}
